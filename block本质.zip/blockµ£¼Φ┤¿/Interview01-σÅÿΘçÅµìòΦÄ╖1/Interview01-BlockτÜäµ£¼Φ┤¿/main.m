//
//  main.m
//  Interview01-Block的本质
//
//  Created by MJ Lee on 2018/5/10.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //局部变量
        // auto：自动变量，离开作用域就销毁
        auto int age = 10; //auto默认省略，就是我们常见的 int age = 10；
        static int height = 10;

        void (^block)(void) = ^{
            // age的值捕获进来（capture）
            NSLog(@"age is %d, height is %d", age, height);
        };

        age = 20;
        height = 20;

        block();
    }
    return 0;
}
